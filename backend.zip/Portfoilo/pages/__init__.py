from .about import about_page
from .project_Discord import project_page
#from .Contact import Contact_page

__all__ = [
    "about_page",
    "project_page",
    #"Contact_page"
]