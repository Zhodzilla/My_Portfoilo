import reflex as rx

config = rx.Config(
    app_name="Portfoilo",
    db_url="sqlite:///reflex.db",
)